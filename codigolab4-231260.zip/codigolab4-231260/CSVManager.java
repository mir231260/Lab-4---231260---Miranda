import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;

public class CSVManager {
    public static void escribirCSV(String nombreArchivo, String contenido) throws IOException {
        try (FileWriter writer = new FileWriter(nombreArchivo, false)) {
            writer.write(contenido);
        }
    }

    public static String leerCSV(String nombreArchivo) throws IOException {
        StringBuilder contenido = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                contenido.append(linea).append("\n");
            }
        }
        return contenido.toString();
    }

    public static void actualizarTipoUsuarioEnCSV(String archivoCSV, String username, String nuevoTipo) throws IOException {
        File archivo = new File(archivoCSV);
        List<String> lineas = Files.readAllLines(archivo.toPath(), StandardCharsets.UTF_8);
        for (int i = 0; i < lineas.size(); i++) {
            String[] partes = lineas.get(i).split(",");
            if (partes.length >= 3 && partes[0].equals(username)) {
                partes[2] = nuevoTipo;
                lineas.set(i, String.join(",", partes));
                break;
            }
        }
        Files.write(archivo.toPath(), lineas, StandardCharsets.UTF_8);
    }
    
}
