import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ImplementacionModoInterfaz implements ModoInterfaz {
    private List<Usuario> usuarios;
    private List<Reserva> reservas;
    private List<Confirmacion> confirmaciones;

    public ImplementacionModoInterfaz() {
        usuarios = new ArrayList<>();
        reservas = new ArrayList<>();
        confirmaciones = new ArrayList<>();

        if (usuarios.isEmpty() && reservas.isEmpty()) {
            leerUsuario();
            leerReserva();
        }
    }

    @Override
    public Usuario login(String username, String password) {
        // Lógica de inicio de sesión
        for (Usuario usuario : usuarios) {
            if (usuario.getUsername().equals(username) && usuario.getPassword().equals(password)) {
                System.out.println("¡Bienvenido de nuevo, " + usuario.getUsername() + "!");
                System.out.println("Recuerda que puedes cambiar tu tipo de cliente a VIP desde el Modo Perfil.");
                                /*
                if (usuario.getTipo() == null || usuario.getTipo().equalsIgnoreCase("gratis")) {
                    usuario.cambiarTipoUsuario("VIP");
                    try {
                        // Actualizar el tipo de usuario en el archivo "usuarios.csv"
                        CSVManager.actualizarTipoUsuarioEnCSV("usuarios.csv", usuario.getUsername(), "VIP");
                        // Agregar a usuarios_premium.csv
                        guardarUsuarioPremium(usuario.getUsername());
                    } catch (IOException e) {
                        // Manejar la excepción según sea necesario
                        e.printStackTrace();
                    }
                }*/
                return usuario;
            }
        }
        return null; // Usuario no encontrado
    }
    

    public void guardarUsuarioPremium(String username) throws IOException {
        // Verificar si el archivo existe, si no, crearlo
        File usuariosPremiumFile = new File("usuarios_premium.csv");
        if (!usuariosPremiumFile.exists()) {
            // Crear el archivo si no existe
            usuariosPremiumFile.createNewFile();
        }

        // Agregar el nuevo usuario Premium al archivo "usuarios_premium.csv"
        try (FileWriter writer = new FileWriter(usuariosPremiumFile, true)) {
            writer.write(username + "\n");
        }
    }

    

    @Override
    public void guardarReserva() throws IOException {
        // Leer el contenido actual del archivo
        String contenidoActual = CSVManager.leerCSV("reservas.csv");
    
        // Agregar las nuevas reservas al contenido existente
        try (FileWriter writer = new FileWriter("reservas.csv")) {
            // Escribir el contenido actual
            writer.write(contenidoActual);
    
            // Agregar las nuevas reservas
            for (Reserva reserva : reservas) {
                writer.write(reserva.getNombreUsuario() + ",");
                writer.write(reserva.getFecha() + ",");
                writer.write(reserva.getTipoVueloString() + ",");
                writer.write(reserva.getCantidadBoletos() + ",");
                writer.write(reserva.getAerolinea() + ",");
                writer.write("\n");
            }
        }
    }

    
    @Override
    public void registroUsuario(String username, String password, String tipo) {
        // Lógica de registro de usuario
        if (usuarios.stream().noneMatch(user -> user.getUsername().equals(username))) {
            Usuario nuevoUsuario = new Usuario();
            nuevoUsuario.setUsername(username);
            nuevoUsuario.setPassword(password);
            // Cambiar el tipo de plan de "gratis" a "VIP"
            nuevoUsuario.setTipo(tipo.equalsIgnoreCase("gratis") ? "gratis" : "VIP");
            usuarios.add(nuevoUsuario);
    
            // Guardar la lista actualizada en el CSV
            try {
                guardarUsuario();
            } catch (IOException e) {
                // Manejar la excepción según sea necesario
                e.printStackTrace();
            }
        } else {
            System.out.println("El usuario ya existe. Inténtelo de nuevo con un nombre diferente.");
        }
    }

    @Override
    public void guardarUsuario() throws IOException {
        // Verificar si el archivo existe, si no, crearlo
        File usuariosFile = new File("usuarios.csv");
        if (!usuariosFile.exists()) {
            // Crear el archivo si no existe
            usuariosFile.createNewFile();
        }
    
        // Escribir la información de los usuarios en el archivo "usuarios.csv"
        try (FileWriter writer = new FileWriter(usuariosFile)) {
            for (Usuario user : usuarios) {
                writer.write(user.getUsername() + ",");
                writer.write(user.getPassword() + ",");
                writer.write(user.getTipo() + "\n");
            }
        }
    }
    


    @Override
    public void leerUsuario() {
        // Limpiamos la lista de usuarios antes de cargar desde el CSV
        usuarios.clear();
        try {
            String contenido = CSVManager.leerCSV("usuarios.csv");
            String[] lineas = contenido.split("\n");
            for (String linea : lineas) {
                String[] partes = linea.split(",");
                if (partes.length >= 3) { // Verificar que hay al menos 3 partes
                    Usuario usuario = new Usuario();
                    usuario.setUsername(partes[0]);
                    usuario.setPassword(partes[1]);
                    usuario.setTipo(partes[2].isEmpty() ? null : partes[2]); // Cambiar aquí
                    usuarios.add(usuario);
                } else if (!linea.trim().isEmpty()) {
                    // Manejar la situación donde no hay suficientes partes en la línea
                    System.out.println("Error al leer usuario: " + linea);
                }
            }
        } catch (IOException e) {
            // Manejar la excepción según sea necesario
            e.printStackTrace();
        }
    }
    


    @Override
    public void cambiarPassword(String nuevaPassword) {
        // Lógica de cambio de contraseña
    }

    @Override
    public void cambiarTipoUsuario() {
        // Lógica de cambio de tipo de usuario
    }

    @Override
    public Usuario buscarUsuarioPorUsername(String username) {
        for (Usuario usuario : usuarios) {
            if (usuario.getUsername().equals(username)) {
                return usuario;
            }
        }
        return null; // Usuario no encontrado
    }



    @Override
    public void reservacion(String fechaVuelo, boolean tipoVuelo, int cantidadBoletos, String aerolinea, String username) {
        // Crear la reserva
        Reserva reserva = new Reserva(username, fechaVuelo, tipoVuelo, cantidadBoletos, aerolinea);

        // Agregar la reserva a la lista
        reservas.add(reserva);

        // Guardar la reserva en el CSV
        try {
            guardarReserva();
        } catch (IOException e) {
            // Manejar la excepción según sea necesario
            e.printStackTrace();
        }
    }
    

    @Override
    public void confirmacion(String numeroTarjeta, int cuotas, String claseVuelo, String numeroAsiento, int cantidadMaletas, String nombreUsuario) {
        // Crear la confirmación de vuelo
        Confirmacion confirmacion = new Confirmacion(numeroTarjeta, cuotas, claseVuelo, numeroAsiento, cantidadMaletas);
        
        // Agregar la confirmación a la lista de confirmaciones
        confirmaciones.add(confirmacion);
        
        // Guardar la confirmación en el CSV
        try {
            guardarConfirmacion(confirmacion, nombreUsuario);
        } catch (IOException e) {
            // Manejar la excepción según sea necesario
            e.printStackTrace();
        }
    }
    
    @Override
    public void guardarConfirmacion(Confirmacion confirmacion, String nombreUsuario) throws IOException {
        // Verificar si el archivo existe, si no, crearlo
        File confirmacionesFile = new File("confirmaciones.csv");
        if (!confirmacionesFile.exists()) {
            // Crear el archivo si no existe
            confirmacionesFile.createNewFile();
        }
    
        // Agregar la nueva confirmación al contenido existente
        try (FileWriter writer = new FileWriter(confirmacionesFile, true)) {
            // Agregar el nombre del usuario que inició la sesión al inicio de cada línea
            writer.write(nombreUsuario + ",");
    
            // Agregar la nueva confirmación
            writer.write(confirmacion.getNumeroTarjeta() + ",");
            writer.write(confirmacion.getCuotas() + ",");
            writer.write(confirmacion.getClaseVuelo() + ",");
            writer.write(confirmacion.getNumeroAsiento() + ",");
            writer.write(confirmacion.getCantidadMaletas() + ",");
            writer.write("\n");
        }
    }

    @Override
    public String itinerario() {
        return null;
        // Lógica de generación de itinerario
    }

    @SuppressWarnings("unused")
    @Override
    public void leerReserva() {
        reservas.clear();
        try {
            String contenido = CSVManager.leerCSV("reservas.csv");
            String[] lineas = contenido.split("\n");
            for (String linea : lineas) {
                // (código existente)
            }
        } catch (IOException e) {
            // (código existente)
        }
    }

    @Override
    public void modoPerfilPremium(Usuario usuario, Scanner scanner) {
        System.out.println("¡Bienvenido al Modo Perfil Premium, " + usuario.getUsername() + "!");
        System.out.println("Seleccione una opción:");
        System.out.println("1. Cambiar contraseña");
        System.out.println("2. Cambiar tipo de cliente");
        System.out.println("3. Volver al menú principal");

        int opcion = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer

        switch (opcion) {
            case 1:
                System.out.print("Ingrese la nueva contraseña: ");
                String nuevaPassword = scanner.nextLine();
                usuario.setPassword(nuevaPassword);
                System.out.println("Contraseña cambiada exitosamente.");
                break;
            case 2:
                System.out.print("Ingrese el nuevo tipo de cliente: ");
                String nuevoTipoCliente = scanner.nextLine();
                usuario.cambiarTipoUsuario(nuevoTipoCliente);
                System.out.println("Tipo de cliente cambiado exitosamente.");
                break;
            case 3:
                // Volver al menú principal
                break;
            default:
                System.out.println("Opción no válida. Inténtelo de nuevo.");
        }
    }

    @Override
    public void modoPerfilNoPremium(Usuario usuario, Scanner scanner) {
        System.out.println("¡Bienvenido al Modo Perfil, " + usuario.getUsername() + "!");
        System.out.println("Seleccione una opción:");
        System.out.println("1. Cambiar contraseña");
        System.out.println("2. Cambiar a modo Premium");
        System.out.println("3. Volver al menú principal");
    
        int opcion = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer
    
        switch (opcion) {
            case 1:
                System.out.print("Ingrese la nueva contraseña: ");
                String nuevaPassword = scanner.nextLine();
                usuario.setPassword(nuevaPassword);
                System.out.println("Contraseña cambiada exitosamente.");
                break;
            case 2:
                // Cambiar de "gratis" a "VIP"
                if (usuario.getTipo() != null && usuario.getTipo().equalsIgnoreCase("gratis")) {
                    usuario.cambiarTipoUsuario("VIP");
                    try {
                        // Actualizar el tipo de usuario en el archivo "usuarios.csv"
                        CSVManager.actualizarTipoUsuarioEnCSV("usuarios.csv", usuario.getUsername(), "VIP");
                        // Agregar a usuarios_premium.csv
                        guardarUsuarioPremium(usuario.getUsername());
                    } catch (IOException e) {
                        // Manejar la excepción según sea necesario
                        e.printStackTrace();
                    }
                    System.out.println("¡Felicidades! Ahora eres un usuario VIP.");
                } else {
                    System.out.println("Ya eres un usuario VIP.");
                }
                break;
            case 3:
                // Volver al menú principal
                break;
            default:
                System.out.println("Opción no válida. Inténtelo de nuevo.");
        }
    }
    
}


