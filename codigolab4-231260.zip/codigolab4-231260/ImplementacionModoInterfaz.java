import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ImplementacionModoInterfaz implements ModoInterfaz {
    private List<Usuario> usuarios;
    private List<Reserva> reservas;
    private List<Confirmacion> confirmaciones;

    public ImplementacionModoInterfaz() {
        usuarios = new ArrayList<>();
        reservas = new ArrayList<>();
        confirmaciones = new ArrayList<>();

        if (usuarios.isEmpty() && reservas.isEmpty()) {
            leerUsuario();
            leerReserva();
        }
    }

    @Override
    public Usuario login(String username, String password) {
   
        for (Usuario usuario : usuarios) {
            if (usuario.getUsername().equals(username) && usuario.getPassword().equals(password)) {
                System.out.println("¡Bienvenido de nuevo, " + usuario.getUsername() + "!");
                System.out.println("Recuerda que puedes cambiar tu tipo de cliente a VIP desde el Modo Perfil.");
                                /*
                if (usuario.getTipo() == null || usuario.getTipo().equalsIgnoreCase("gratis")) {
                    usuario.cambiarTipoUsuario("VIP");
                    try {
                        // Actualizar el tipo de usuario en el archivo "usuarios.csv"
                        CSVManager.actualizarTipoUsuarioEnCSV("usuarios.csv", usuario.getUsername(), "VIP");
                        // Agregar a usuarios_premium.csv
                        guardarUsuarioPremium(usuario.getUsername());
                    } catch (IOException e) {
                        // Manejar la excepción según sea necesario
                        e.printStackTrace();
                    }
                }*/
                return usuario;
            }
        }
        return null; 
    }
    

    public void guardarUsuarioPremium(String username) throws IOException {
       
        File usuariosPremiumFile = new File("usuarios_premium.csv");
        if (!usuariosPremiumFile.exists()) {
           
            usuariosPremiumFile.createNewFile();
        }
        try (FileWriter writer = new FileWriter(usuariosPremiumFile, true)) {
            writer.write(username + "\n");
        }
    }

    

    @Override
    public void guardarReserva() throws IOException {
        String contenidoActual = CSVManager.leerCSV("reservas.csv");
    
        try (FileWriter writer = new FileWriter("reservas.csv")) {
       
            writer.write(contenidoActual);
    
            for (Reserva reserva : reservas) {
                writer.write(reserva.getNombreUsuario() + ",");
                writer.write(reserva.getFecha() + ",");
                writer.write(reserva.getTipoVueloString() + ",");
                writer.write(reserva.getCantidadBoletos() + ",");
                writer.write(reserva.getAerolinea() + ",");
                writer.write("\n");
            }
        }
    }

    
    @Override
    public void registroUsuario(String username, String password, String tipo) {
        
        if (usuarios.stream().noneMatch(user -> user.getUsername().equals(username))) {
            Usuario nuevoUsuario = new Usuario();
            nuevoUsuario.setUsername(username);
            nuevoUsuario.setPassword(password);
            
            nuevoUsuario.setTipo(tipo.equalsIgnoreCase("gratis") ? "gratis" : "VIP");
            usuarios.add(nuevoUsuario);
    
            
            try {
                guardarUsuario();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("El usuario ya existe. Inténtelo de nuevo con un nombre diferente.");
        }
    }

    @Override
    public void guardarUsuario() throws IOException {
        File usuariosFile = new File("usuarios.csv");
        if (!usuariosFile.exists()) {
            usuariosFile.createNewFile();
        }
    
        try (FileWriter writer = new FileWriter(usuariosFile)) {
            for (Usuario user : usuarios) {
                writer.write(user.getUsername() + ",");
                writer.write(user.getPassword() + ",");
                writer.write(user.getTipo() + "\n");
            }
        }
    }
    


    @Override
    public void leerUsuario() {
        usuarios.clear();
        try {
            String contenido = CSVManager.leerCSV("usuarios.csv");
            String[] lineas = contenido.split("\n");
            for (String linea : lineas) {
                String[] partes = linea.split(",");
                if (partes.length >= 3) { 
                    Usuario usuario = new Usuario();
                    usuario.setUsername(partes[0]);
                    usuario.setPassword(partes[1]);
                    usuario.setTipo(partes[2].isEmpty() ? null : partes[2]); 
                    usuarios.add(usuario);
                } else if (!linea.trim().isEmpty()) {
                    System.out.println("Error al leer usuario: " + linea);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    


    @Override
    public void cambiarPassword(String nuevaPassword) {
    }

    @Override
    public void cambiarTipoUsuario() {
    }

    @Override
    public Usuario buscarUsuarioPorUsername(String username) {
        for (Usuario usuario : usuarios) {
            if (usuario.getUsername().equals(username)) {
                return usuario;
            }
        }
        return null; 
    }



    @Override
    public void reservacion(String fechaVuelo, boolean tipoVuelo, int cantidadBoletos, String aerolinea, String username) {
        Reserva reserva = new Reserva(username, fechaVuelo, tipoVuelo, cantidadBoletos, aerolinea);

        reservas.add(reserva);

        try {
            guardarReserva();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

    @Override
    public void confirmacion(String numeroTarjeta, int cuotas, String claseVuelo, String numeroAsiento, int cantidadMaletas, String nombreUsuario) {
        Confirmacion confirmacion = new Confirmacion(numeroTarjeta, cuotas, claseVuelo, numeroAsiento, cantidadMaletas);
        
        confirmaciones.add(confirmacion);
        
        try {
            guardarConfirmacion(confirmacion, nombreUsuario);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void guardarConfirmacion(Confirmacion confirmacion, String nombreUsuario) throws IOException {
        File confirmacionesFile = new File("confirmaciones.csv");
        if (!confirmacionesFile.exists()) {
            confirmacionesFile.createNewFile();
        }
    
        try (FileWriter writer = new FileWriter(confirmacionesFile, true)) {
            writer.write(nombreUsuario + ",");
    
            writer.write(confirmacion.getNumeroTarjeta() + ",");
            writer.write(confirmacion.getCuotas() + ",");
            writer.write(confirmacion.getClaseVuelo() + ",");
            writer.write(confirmacion.getNumeroAsiento() + ",");
            writer.write(confirmacion.getCantidadMaletas() + ",");
            writer.write("\n");
        }
    }

    @Override
    public String itinerario() {
        return null;
    }

    @SuppressWarnings("unused")
    @Override
    public void leerReserva() {
        reservas.clear();
        try {
            String contenido = CSVManager.leerCSV("reservas.csv");
            String[] lineas = contenido.split("\n");
            for (String linea : lineas) {
            }
        } catch (IOException e) {
        }
    }

    @Override
    public void modoPerfilPremium(Usuario usuario, Scanner scanner) {
        System.out.println("¡Bienvenido al Modo Perfil Premium, " + usuario.getUsername() + "!");
        System.out.println("Seleccione una opción:");
        System.out.println("1. Cambiar contraseña");
        System.out.println("2. Cambiar tipo de cliente");
        System.out.println("3. Volver al menú principal");

        int opcion = scanner.nextInt();
        scanner.nextLine(); 

        switch (opcion) {
            case 1:
                System.out.print("Ingrese la nueva contraseña: ");
                String nuevaPassword = scanner.nextLine();
                usuario.setPassword(nuevaPassword);
                System.out.println("Contraseña cambiada exitosamente.");
                break;
            case 2:
                System.out.print("Ingrese el nuevo tipo de cliente: ");
                String nuevoTipoCliente = scanner.nextLine();
                usuario.cambiarTipoUsuario(nuevoTipoCliente);
                System.out.println("Tipo de cliente cambiado exitosamente.");
                break;
            case 3:
                break;
            default:
                System.out.println("Opción no válida. Inténtelo de nuevo.");
        }
    }

    @Override
    public void modoPerfilNoPremium(Usuario usuario, Scanner scanner) {
        System.out.println("¡Bienvenido al Modo Perfil, " + usuario.getUsername() + "!");
        System.out.println("Seleccione una opción:");
        System.out.println("1. Cambiar contraseña");
        System.out.println("2. Cambiar a modo Premium");
        System.out.println("3. Volver al menú principal");
    
        int opcion = scanner.nextInt();
        scanner.nextLine(); 
    
        switch (opcion) {
            case 1:
                System.out.print("Ingrese la nueva contraseña: ");
                String nuevaPassword = scanner.nextLine();
                usuario.setPassword(nuevaPassword);
                System.out.println("Contraseña cambiada exitosamente.");
                break;
            case 2:
                if (usuario.getTipo() != null && usuario.getTipo().equalsIgnoreCase("gratis")) {
                    usuario.cambiarTipoUsuario("VIP");
                    try {
                        CSVManager.actualizarTipoUsuarioEnCSV("usuarios.csv", usuario.getUsername(), "VIP");
                        guardarUsuarioPremium(usuario.getUsername());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("¡Felicidades! Ahora eres un usuario VIP.");
                } else {
                    System.out.println("Ya eres un usuario VIP.");
                }
                break;
            case 3:
                break;
            default:
                System.out.println("Opción no válida. Inténtelo de nuevo.");
        }
    }
    
}


